package org.hbrs.se1.ws21.uebung11;

public class MyPoint {
    double x, y;
    MyPoint(double x, double y){
        this.x = x;
        this.y = y;
    }
}
