package org.hbrs.se1.ws21.solutions.uebung3;

enum Modus {
	
	LIST_TYPE_ARRAY , LIST_TYPE_LINKED, LIST_TYPE_CUSTOM
}

