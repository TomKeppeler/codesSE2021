Mitarbeiter:{
    ID,
    Vorname,
    Nachname,
    Rolle,
    Abteil,
    Expertise-Level;
}

