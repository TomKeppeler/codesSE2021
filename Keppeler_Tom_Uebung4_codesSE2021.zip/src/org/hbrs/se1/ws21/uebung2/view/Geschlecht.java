package org.hbrs.se1.ws21.uebung2.view;

public enum Geschlecht {
    WEIBLICH,
    MAENLICH,
    DIVERS
}
