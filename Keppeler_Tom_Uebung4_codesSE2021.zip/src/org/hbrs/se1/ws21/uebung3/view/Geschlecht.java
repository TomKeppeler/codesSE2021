package org.hbrs.se1.ws21.uebung3.view;

public enum Geschlecht {
    WEIBLICH,
    MAENLICH,
    DIVERS
}
